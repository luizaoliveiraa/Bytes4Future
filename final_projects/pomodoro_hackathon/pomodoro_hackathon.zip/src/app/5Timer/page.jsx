'use client'

import React from 'react';
import TimerFiveMinutes from '@/components/timer/5Timer';

const TimerFiveMinutesPage = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <TimerFiveMinutes />
    </div>
  );
};

export default TimerFiveMinutesPage;