import React from "react";

function chat() {
  return <div>chat</div>;
}

export default chat;
